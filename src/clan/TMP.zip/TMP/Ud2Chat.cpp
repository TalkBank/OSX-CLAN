/**********************************************************************
	"Copyright 1990-2023 Brian MacWhinney. Use is subject to Gnu Public License
	as stated in the attached "gpl.txt" file."
*/


#define CHAT_MODE 1
#include "cu.h"
#include "check.h"
#ifndef UNX
#include "ced.h"
#else
#define RGBColor int
#include "c_curses.h"
#endif
#ifdef _WIN32 
	#include "stdafx.h"
#endif

#if !defined(UNX)
#define _main ud2chat_main
#define call ud2chat_call
#define getflag ud2chat_getflag
#define init ud2chat_init
#define usage ud2chat_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 


#define LABELS struct labels_list
LABELS {
	char *from;
	char *to;
	LABELS *next_label;
};

extern char OverWriteFile;
extern char outputOnlyData;

static const char *trans_file;
static char ud2chat_ftime;
static LABELS *labelsRoot;

static LABELS *freeLabels(LABELS *p) {
	LABELS *t;
	
	while (p != NULL) {
		t = p;
		p = p->next_label;
		if (t->from)
			free(t->from);
		if (t->to)
			free(t->to);
		free(t);
	}
	return(NULL);
}


static void ud2chat_error(const char *mess) {
	labelsRoot = freeLabels(labelsRoot);
	fprintf(stderr, "%s\n", mess);
	cutt_exit(0);
}

static void ud2chat_addNewTrans(char *from, char *to, int ln) {
	LABELS *p;

	if (labelsRoot == NULL) {
		labelsRoot = NEW(LABELS);
		p = labelsRoot;
	} else {
		for (p=labelsRoot; p->next_label != NULL; p=p->next_label) {
			if (uS.mStricmp(p->from, from) == 0) {
				fprintf(stderr, "\nType \"%s\" is specified twice in translation file \"%s\" on line %d\n\n", from, trans_file, ln);
				return;
			}
		}
		p->next_label = NEW(LABELS);
		p = p->next_label;
	}
	if (p == NULL) {
		ud2chat_error("Error: out of memory");
	}
	p->next_label = NULL;
	
	p->from = (char *)malloc(strlen(from)+1);
	if (p->from == NULL)
		ud2chat_error("Error: out of memory");
	strcpy(p->from, from);
	
	p->to = (char *)malloc(strlen(to)+1);
	if (p->to == NULL)
		ud2chat_error("Error: out of memory");
	strcpy(p->to, to);
}

static void read_trans(const char *trans) {
	int  ln;
	char *from, *to, t;
	FNType mFileName[FNSize];
	FILE *fp;

	strcpy(mFileName, lib_dir);
	addFilename2Path(mFileName, "ud2chat");
	addFilename2Path(mFileName, trans);
	if ((from=strchr(trans, '.')) != NULL) {
		if (uS.mStricmp(from, ".cut") != 0)
			strcat(mFileName, ".cut");
	} else
		strcat(mFileName, ".cut");
	if ((fp=fopen(mFileName,"r")) == NULL) {
		if (from != NULL) {
			if (uS.mStricmp(from, ".cut") == 0) {
				strcpy(templineC, wd_dir);
				addFilename2Path(templineC, trans);
				if ((fp=fopen(templineC, "r")) != NULL) {
					strcpy(mFileName, templineC);
				}
			}
		}
	}
	if (fp == NULL) {
		fprintf(stderr, "\nERROR: Can't locate translation file: \"%s\".\n", mFileName);
#ifdef _MAC_CODE
		fprintf(stderr, "\n");
#else
		fprintf(stderr, "Check to see if \"lib\" directory in Commands window is set correctly.\n\n");
#endif
		cutt_exit(0);
	}
	fprintf(stderr,"    Using translation file: %s\n", mFileName);
	ln = 0;
	while (fgets_cr(templineC, UTTLINELEN, fp)) {
		if (uS.isUTF8(templineC) || uS.isInvisibleHeader(templineC) ||
			strncmp(templineC, SPECIALTEXTFILESTR, SPECIALTEXTFILESTRLEN) == 0)
			continue;
		ln++;
		if (templineC[0] == '%' || templineC[0] == '#')
			continue;
		uS.remFrontAndBackBlanks(templineC);
		if (templineC[0] == EOS)
			continue;
		from = templineC;
		for (to=from; !isSpace(*to) && *to != EOS; to++) ;
		t = *to;
		*to = EOS;
		if (t != EOS) {
			to++;
			for (; isSpace(*to); to++) ;
			if (*to != EOS)
				ud2chat_addNewTrans(from, to, ln);
			else
				ud2chat_addNewTrans(from, from, ln);
		} else {
			ud2chat_addNewTrans(from, from, ln);
		}
	}
	fclose(fp);
}

void init(char f) {
	if (f) {
		trans_file = "0ud.cut";
		labelsRoot = NULL;
		ud2chat_ftime = TRUE;
		stout = FALSE;
		OverWriteFile = TRUE;
		outputOnlyData = TRUE;
//		AddCEXExtension = ".cha";
		LocalTierSelect = TRUE;
		onlydata = 1;
	} else if (ud2chat_ftime) {
		ud2chat_ftime = FALSE;
		if (trans_file == NULL) {
			fprintf(stderr,"Please specify translation file name with \"+l\" option.\n");
			fprintf(stderr,"For example, \"ud2chat +lud\" or \"ud2chat +lud.cut\".\n");
			cutt_exit(0);
		}
		read_trans(trans_file);
	}
}

void usage() {
	printf("Conver UD notation to CHAT notation\n");
	printf("Usage: ud2chat [lF oN %s] filename(s)\n", mainflgs());
	fprintf(stdout, "+lF: specify translation file (default: %s)", trans_file);
#ifdef UNX
	puts("+LF: specify full path F of the lib folder");
#endif
	mainusage(FALSE);
	puts("Example:");
#ifdef _WIN32
	puts("   To use \"ud.cut\" translation file located in CLAN\\lib\\ud2chat folder");
#else
	puts("   To use \"ud.cut\" translation file located in CLAN/lib/ud2chat folder");
#endif
	puts("       ud2chat +lud ...");
	puts("       ud2chat +lud.cut ...");
	cutt_exit(0);
}

void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		case 'l':
			if (*f == EOS) {
				fprintf(stderr, "Please specify translation file\n");
				cutt_exit(0);
			}
			trans_file = f;
			break;
#ifdef UNX
		case 'L':
			int j;
			strcpy(lib_dir, f);
			j = strlen(lib_dir);
			if (j > 0 && lib_dir[j-1] != '/')
				strcat(lib_dir, "/");
			break;
#endif
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}

static int replacePOS(char *line, int b, char *to) {
	int i, e;

	for (e=b; e >= 0 && line[e] != '|' && !isSpace(line[e]); e--) ;
	if (line[e] == '|') {
		for (b=e; b >= 0 && !isSpace(line[b]) && line[b] != '\n' &&
			 line[b] != '+' && line[b] != '~' && line[b] != '#'; b--) ;
		b++;
		strcpy(line+b, line+e);
		uS.shiftright(line+b, strlen(to));
		for (i=0, e=b; to[i] != EOS; i++, e++) {
			line[e] = to[i];
		}
	}
	return(b);
}

static int checkMorItem(char *line, int b, int e) {
	int i, j;
	LABELS *p;

	for (p=labelsRoot; p != NULL; p=p->next_label) {
		if (p->from[0] != '0' || p->from[1] != '|') {
			if (strcmp(p->from, p->to) != 0) {
				for (i=0, j=b; p->from[i] == line[j] && j < e; i++, j++) ;
				if (j == e) {
					strcpy(line+b, line+e);
					if (p->from[0] == '-' && p->to[0] != '-') {
						j = replacePOS(line, b, p->to);
					} else {
						uS.shiftright(line+b, strlen(p->to));
						for (i=0, j=b; p->to[i] != EOS; i++, j++) {
							line[j] = p->to[i];
						}
					}
					return(j);
				}
			}
		}
	}
	return(e);
}

static int checkGraItem(char *line, int b, int e) {
	int i, ti, tb;
	LABELS *p;

	for (; (isdigit(line[b]) || line[b] == '|') && b < e; b++) ;
	for (p=labelsRoot; p != NULL; p=p->next_label) {
		if (p->from[0] == '0' && p->from[1] == '|') {
			if (strcmp(p->from, p->to) != 0) {
				for (i=0; (isdigit(p->from[i]) || p->from[i] == '|') && p->from[i] != EOS; i++) ;
				for (ti=i, tb=b; p->from[ti] == line[tb] && tb < e; ti++, tb++) ;
				if (tb == e) {
					strcpy(line+b, line+e);
					uS.shiftright(line+b, strlen(p->to));
					for (i=0; p->to[i] != EOS; i++, b++) {
						line[b] = p->to[i];
					}
					return(b);
				}
			}
		}
	}
	return(e);
}

/*
 IXXS prefix[NUM_PREF];
 char *pos;
 char *stem;
 IXXS suffix[NUM_SUFF];
 IXXS fusion[NUM_FUSI];
 IXXS error[NUM_ERRS];
 */
void call() {
	int  b, e;
//	int  i;
//	char word[BUFSIZ+1];
//	MORFEATS word_feats, *clitic, *feat;

	currentatt = 0;
	currentchar = (char)getc_cr(fpin, &currentatt);
	while (getwholeutter()) {
		if (utterance->speaker[0] == '*') {
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
		} else if (uS.partcmp(utterance->speaker, "%mor:", FALSE, FALSE)) {
/*
			i = 0;
			while ((i=getword(utterance->speaker, uttline, templineC, NULL, i))) {
				if (isWordFromMORTier(templineC)) {
					if (ParseWordMorElems(templineC, &word_feats) == FALSE)
						ud2chat_error("Error: out of memory");
					for (clitic=&word_feats; clitic != NULL; clitic=clitic->clitc) {
						if (clitic->compd != NULL) {
							word[0] = EOS;
							for (feat=clitic; feat != NULL; feat=feat->compd) {
								if (isEqual("v", feat->pos)) {
								}
								if (isEqualIxes("PASTP",feat->suffix,NUM_SUFF)) {
								}
								if (isEqualIxes("PRESP",feat->suffix,NUM_SUFF)) {
								}
								if (isEqualIxes("PASTP",feat->fusion,NUM_FUSI)) {
								}
								if (isEqualIxes("PRESP",feat->fusion,NUM_FUSI)) {
								}
							}
						} else {
							if (isEqual("v", clitic->pos)) {
							}
							if (isEqualIxes("PASTP",clitic->suffix,NUM_SUFF)) {
							}
							if (isEqualIxes("PRESP",clitic->suffix,NUM_SUFF)) {
							}
							if (isEqualIxes("PASTP",clitic->fusion,NUM_FUSI)) {
							}
							if (isEqualIxes("PRESP",clitic->fusion,NUM_FUSI)) {
							}
						}
					}
					freeUpFeats(&word_feats);
				}
			}
*/ 
			b = 0;
			while (utterance->line[b] != EOS) {
				while (isSpace(utterance->line[b]) || utterance->line[b] == '\n' ||
					   utterance->line[b] == '+' || utterance->line[b] == '~')
					b++;
				for (e=b+1; utterance->line[e] != EOS && utterance->line[e] != '#' && utterance->line[e] != '|' &&
					 utterance->line[e] != '-' && utterance->line[e] != '&' &&utterance->line[e] != '=' &&
					 utterance->line[e] != '~' && utterance->line[e] != '+' &&
					 !isSpace(utterance->line[e]) && utterance->line[e] != '\n'; e++) ;
				if (utterance->line[b] == '|') {
					b = e;
				} else {
					b = checkMorItem(utterance->line, b, e);
				}
			}
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
		} else if (uS.partcmp(utterance->speaker, "%gra:", FALSE, FALSE)) {
			b = 0;
			while (utterance->line[b] != EOS) {
				while (isSpace(utterance->line[b]) || utterance->line[b] == '\n')
					b++;
				for (e=b+1; utterance->line[e] != EOS && !isSpace(utterance->line[e]) && utterance->line[e] != '\n'; e++) ;
				b = checkGraItem(utterance->line, b, e);
			}
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
		} else {
			printout(utterance->speaker,utterance->line,utterance->attSp,utterance->attLine,FALSE);
		}
	}
}

CLAN_MAIN_RETURN main(int argc, char *argv[]) {
	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = UD2CHAT;
	OnlydataLimit = 2;
	UttlineEqUtterance = FALSE;
#ifdef UNX
	int i, j;
	for (i=1; i < argc; i++) {
		if (*argv[i] == '+'  || *argv[i] == '-') {
			if (argv[i][1] == 'L') {
				strcpy(lib_dir, argv[i]+2);
				j = strlen(lib_dir);
				if (j > 0 && lib_dir[j-1] != '/')
					strcat(lib_dir, "/");
			}
		}
	}
#endif
	bmain(argc,argv,NULL);
	labelsRoot = freeLabels(labelsRoot);
}
