/**********************************************************************
	"Copyright 1990-2022 Brian MacWhinney. Use is subject to Gnu Public License
	as stated in the attached "gpl.txt" file."
 */

#define CHAT_MODE 3

#include "cu.h"

#if !defined(UNX)
#define _main temp_main
#define call temp_call
#define getflag temp_getflag
#define init temp_init
#define usage temp_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 

#define BULLETLESSWORMAX 5

struct rtiers {
	char *sp;	/* code descriptor field of the turn	 */
	char *line;		/* text field of the turn		 */
	char *lineOrg;	/* text field of the turn		 */
	char matched;
	long lineno;
	struct rtiers *nexttier;	/* pointer to the next utterance, if	 */
} ;				/* there is only 1 utterance, i.e. no	 */

extern struct tier *defheadtier;
extern char OverWriteFile;

static char isFTime;
static const char *bDefDelim;

static char isPostCode(char *line, int *i) {
	int t = *i;
	
	if (line[t] != ']')
		return(FALSE);
	for (t--; line[t] != '[' && t >= 0; t--) ;
	if (t < 0)
		return(FALSE);
	if (line[t+1] == '+' && line[t+2] == ' ') {
		*i = t - 1;
		return(TRUE);
	}
	return(FALSE);
}

static void b_delim_anal(char *line) {
	register int i, j;
	char sb = FALSE, hid = FALSE;
	
	i = strlen(line) - 1;
	while (i >= 0) {
		if (!isSpace(line[i]) && line[i] != '\n') {
			if (line[i] == HIDEN_C)
				hid = !hid;
			else if (line[i] == ']')
				sb = TRUE;
			else if (line[i] == '[')
				sb = FALSE;
			else if (!sb && !hid) {
				if (!uS.IsUtteranceDel(line, i)) {
					if (line[i] == '-' && line[i+1] == ' ')
						line[i+1] = '.';
					else {
						i = strlen(line) - 1;
						do {
							for (; i >= 0 && (isSpace(line[i]) || line[i] == '\n'); i--) ;
							if ( i < 0)
								break;
							if (line[i] == HIDEN_C) {
								for (i--; line[i] != HIDEN_C && i >= 0; i--) ;
								if (i >= 0)
									i--;
							} else if (isPostCode(line, &i))
								;
							else
								break;
						} while (i >= 0) ;
						i++;
						att_shiftright(line+i, utterance->attLine+i, strlen(bDefDelim)+1);
						line[i++] = ' ';
						for (j=0; bDefDelim[j] != EOS; j++)
							line[i++] = bDefDelim[j];
					}
				}
				break;
			}
		}
		i--;
	}
}

static void breaupMainMorTiers(char *sp, char *main, char *mor) {
	int bm, m, bw, w;

	bw = 0;
	bm = 0;
	for (m=bm; main[m] != EOS; m++) {
		if (main[m] == ',' && main[m-1] != '+') {
			for (w=bw; mor[w] != EOS; w++) {
				if (mor[w] == ',' && mor[w-1] != '+') {
					main[m] = EOS;
					mor[w] = EOS;
					strcpy(templineC, main+bm);
					uS.remFrontAndBackBlanks(templineC);
					removeExtraSpace(templineC);
					b_delim_anal(templineC);
					printout(sp, templineC, NULL, NULL, TRUE);
					strcpy(templineC, mor+bw);
					uS.remFrontAndBackBlanks(templineC);
					removeExtraSpace(templineC);
					b_delim_anal(templineC);
					printout("%mor:", templineC, NULL, NULL, TRUE);
					bm = m + 1;
					m = bm;
					bw = w + 1;
					w = bw;
					break;
				}
			}
			if (mor[w] == EOS) {
				main[m] = EOS;
				strcpy(templineC, main+bm);
				uS.remFrontAndBackBlanks(templineC);
				removeExtraSpace(templineC);
				b_delim_anal(templineC);
				printout(sp, templineC, NULL, NULL, TRUE);
				if (mor[bw] != EOS) {
					strcpy(templineC, mor+bw);
					uS.remFrontAndBackBlanks(templineC);
					removeExtraSpace(templineC);
					b_delim_anal(templineC);
					printout("%mor:", templineC, NULL, NULL, TRUE);
				}
				bm = m + 1;
				m = bm;
				bw = w;
			}
		}
	}
	if (main[m] == EOS) {
		if (main[bm] != EOS) {
			strcpy(templineC, main+bm);
			uS.remFrontAndBackBlanks(templineC);
			removeExtraSpace(templineC);
			b_delim_anal(templineC);
			printout(sp, templineC, NULL, NULL, TRUE);
			bm = m;
		}
		for (w=bw; mor[w] != EOS; w++) {
			if (mor[w] == ',' && mor[w-1] != '+') {
				mor[w] = EOS;
				strcpy(templineC, mor+bw);
				uS.remFrontAndBackBlanks(templineC);
				removeExtraSpace(templineC);
				b_delim_anal(templineC);
				printout("%mor:", templineC, NULL, NULL, TRUE);
				bw = w + 1;
				w = bw;
			}
		}
		if (mor[w] == EOS) {
			if (mor[bw] != EOS) {
				strcpy(templineC, mor+bw);
				uS.remFrontAndBackBlanks(templineC);
				removeExtraSpace(templineC);
				b_delim_anal(templineC);
				printout("%mor:", templineC, NULL, NULL, TRUE);
			}
			bm = m;
			bw = w;
		}
	}		
}

void call() {
	char sp[SPEAKERLEN];
	
	sp[0] = EOS;
	spareTier1[0] = EOS;
	spareTier2[0] = EOS;
	currentatt = 0;
	currentchar = (char)getc_cr(fpin, &currentatt);
	while (getwholeutter()) {
		if (utterance->speaker[0] == '*') {
			if (spareTier1[0] != EOS) {
				printout(sp, spareTier1, NULL, NULL, TRUE);
			}
			strcpy(sp, utterance->speaker);
			strcpy(spareTier1, utterance->line);
		} else if (uS.partcmp(utterance->speaker,"%mor:",FALSE,FALSE)) {
			strcpy(spareTier2, utterance->line);
			breaupMainMorTiers(sp, spareTier1, spareTier2);
			spareTier1[0] = EOS;
		} else {
			if (spareTier1[0] != EOS) {
				printout(sp, spareTier1, NULL, NULL, TRUE);
				spareTier1[0] = EOS;
			}
			printout(utterance->speaker, utterance->line, NULL, NULL, TRUE);
		}
	}
}

void init(char f) {
	if (f) {
		isFTime = TRUE;
		OverWriteFile = TRUE;
		FilterTier = 0;
		LocalTierSelect = TRUE;
		bDefDelim = ".";
		if (defheadtier) {
			if (defheadtier->nexttier != NULL)
				free(defheadtier->nexttier);
			free(defheadtier);
			defheadtier = NULL;
		}
	} else {
		if (isFTime) {
			onlydata = 1;
			isFTime = FALSE;
		}
	}
}

void usage() {
	printf("breakup tier at commas\n");
	printf("Usage: temp filename(s)\n");
	mainusage(TRUE);
}


CLAN_MAIN_RETURN main(int argc, char *argv[]) {

	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = TEMP;
	OnlydataLimit = 0;
	UttlineEqUtterance = FALSE;
	bmain(argc,argv,NULL);
}

void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}
