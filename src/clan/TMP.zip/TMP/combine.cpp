/**********************************************************************
 "Copyright 1990-2019 Brian MacWhinney. Use is subject to Gnu Public License
 as stated in the attached "gpl.txt" file."
 */

#define CHAT_MODE 3
#include "cu.h"

#if !defined(UNX)
#define _main combine_main
#define call combine_call
#define getflag combine_getflag
#define init combine_init
#define usage combine_usage
#endif

#define IS_WIN_MODE FALSE
#include "mul.h" 

extern struct tier *defheadtier;
extern char OverWriteFile;

#define COMB_UTT struct combine_utts
COMB_UTT {
	long beg;
    char *speaker;		/* code descriptor field of the turn	*/
    AttTYPE *attSp;		/* Attributes assiciated with speaker name	*/
    char *line;		/* text field of the turn		*/ // found uttlinelen
    AttTYPE *attLine;	/* Attributes assiciated with text*/
    COMB_UTT *next;
} ;

static char isFirstFile;
static COMB_UTT *root_utt;

void usage() {
	printf("Usage: combine [%s] filename(s)\n",mainflgs());
	mainusage(TRUE);
}

void init(char f) {
	if (f) {
		root_utt = NULL;
		isFirstFile = TRUE;
		combinput = TRUE;
		stout = FALSE;
		onlydata = 1;
		OverWriteFile = TRUE;
		FilterTier = 0;
		LocalTierSelect = TRUE;
		if (defheadtier != NULL) {
			if (defheadtier->nexttier != NULL)
				free(defheadtier->nexttier);
			free(defheadtier);
			defheadtier = NULL;
		}
	}
}

static COMB_UTT *freeCombUtts(COMB_UTT *p) {
	COMB_UTT *t;

	while (p != NULL) {
		t = p;
		p = p->next;
		if (t->speaker != NULL)
			free(t->speaker);
		if (t->attSp != NULL)
			free(t->attSp);
		if (t->line != NULL)
			free(t->line);
		if (t->attLine != NULL)
			free(t->attLine);
		free(t);
	}
	return(NULL);
}

static COMB_UTT *add2TempUtts(COMB_UTT *root) {
	int len;
	COMB_UTT *utt;

	if (root == NULL) {
		utt = NEW(COMB_UTT);
		if (utt == NULL) {
			fprintf(stderr,"Error: out of memory\n");
			root = freeCombUtts(root);
			root_utt = freeCombUtts(root_utt);
			cutt_exit(0);
		}
		root = utt;
	} else {
		for (utt=root; utt->next != NULL; utt=utt->next) ;
		if ((utt->next=NEW(COMB_UTT)) == NULL) {
			fprintf(stderr,"Error: out of memory\n");
			root = freeCombUtts(root);
			root_utt = freeCombUtts(root_utt);
			cutt_exit(0);
		}
		utt = utt->next;
	}
	utt->next = NULL;
	utt->speaker = NULL;
	utt->attSp = NULL;
	utt->line = NULL;
	utt->attLine = NULL;
	len = strlen(utterance->speaker) + 1;
	utt->speaker = (char *)malloc(len);
	utt->attSp = (AttTYPE *)malloc(len*sizeof(AttTYPE));
	if (utt->speaker == NULL || utt->attSp == NULL) {
		fprintf(stderr,"Error: out of memory\n");
		root = freeCombUtts(root);
		root_utt = freeCombUtts(root_utt);
		cutt_exit(0);
	}
	att_cp(0L, utt->speaker, utterance->speaker, utt->attSp, utterance->attSp);
	len = strlen(utterance->line) + 1;
	utt->line = (char *)malloc(len);
	utt->attLine = (AttTYPE *)malloc(len*sizeof(AttTYPE));
	if (utt->line == NULL || utt->attLine == NULL) {
		fprintf(stderr,"Error: out of memory\n");
		root = freeCombUtts(root);
		root_utt = freeCombUtts(root_utt);
		cutt_exit(0);
	}
	att_cp(0L, utt->line, utterance->line, utt->attLine, utterance->attLine);
	return(root);
}

static COMB_UTT *add2CombUtts(COMB_UTT *root, COMB_UTT *cur) {
	COMB_UTT *utt, *tutt;

	for (utt=cur->next; utt != NULL; utt=utt->next) {
		utt->beg = cur->beg;
	}
	if (root == NULL) {
		root = cur;
	} else if (cur->speaker[0] != '*') {
		for (utt=root; utt->next != NULL; utt=utt->next) ;
		utt->next = cur;
	} else {
		tutt= root;
		utt = root;
		while (utt != NULL) {
			if (cur->beg < utt->beg)
				break;
			tutt = utt;
			utt = utt->next;
		}
		if (utt == NULL) {
			tutt->next = cur;
		} else if (utt == root) {
			root = cur;
			for (tutt=root; tutt->next != NULL; tutt=tutt->next) ;
			tutt->next = utt;
		} else {
			for (utt=cur; utt->next != NULL; utt=utt->next) ;
			utt->next = tutt->next;
			tutt->next = cur;
		}
	}
	return(root);
}

static long getTime(char *s, long beg) {
	while (*s != EOS) {
		if (*s == HIDEN_C) {
			s++;
			while (*s != EOS && *s != HIDEN_C && !isdigit(*s))
				s++;
			if (isdigit(*s)) {
				beg = atol(s);
			}
			while (*s != EOS && *s != HIDEN_C)
				s++;
			if (*s != EOS)
				s++;
		} else
			s++;
	}
	return(beg);
}

void call() {
	char isFirstSpFound;
	long beg;
	COMB_UTT *cur_utt;

	beg = 0L;
	isFirstSpFound = FALSE;
	cur_utt = NULL;
	currentatt = 0;
	currentchar = (char)getc_cr(fpin, &currentatt);
	while (getwholeutter()) {
		if (utterance->speaker[0] == '*') {
			if (cur_utt != NULL) {
				beg = getTime(cur_utt->line, beg);
				cur_utt->beg = beg;
				root_utt = add2CombUtts(root_utt, cur_utt);
				cur_utt = NULL;
			}
			isFirstSpFound = TRUE;
		}
		if (isFirstSpFound || isFirstFile) {
			if (!uS.partcmp(utterance->speaker, "@End", FALSE, FALSE))
				cur_utt = add2TempUtts(cur_utt);
		}
	}
	if (cur_utt != NULL) {
		beg = getTime(cur_utt->line, beg);
		cur_utt->beg = beg;
		root_utt = add2CombUtts(root_utt, cur_utt);
		cur_utt = NULL;
	}
	isFirstFile = FALSE;
}

static void pr_result(void) {
	COMB_UTT *utt;

	for (utt=root_utt; utt->next != NULL; utt=utt->next) {
		printout(utt->speaker, utt->line, utt->attSp, utt->attLine, FALSE);
	}
	printout("@End", NULL, NULL, NULL, FALSE);
	root_utt = freeCombUtts(root_utt);
}

CLAN_MAIN_RETURN main(int argc, char *argv[]) {
	isWinMode = IS_WIN_MODE;
	chatmode = CHAT_MODE;
	CLAN_PROG_NUM = TEMP02;
	OnlydataLimit = 0;
	UttlineEqUtterance = TRUE;
	bmain(argc,argv,pr_result);
}
		
void getflag(char *f, char *f1, int *i) {
	f++;
	switch(*f++) {
		default:
			maingetflag(f-2,f1,i);
			break;
	}
}
